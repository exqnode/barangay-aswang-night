# 🎮 HOW TO PLAY - Barangay: Aswang Night

## 🌙 THE GAME

**8 players. 1 secret Aswang. 5 minutes. Can you survive?**

---

## 👥 THE ROLES

### 🧑 YOU'RE A VILLAGER (7 players)
**Your Goal:** Complete your tasks and vote out the Aswang

**How to Win:**
- Finish ALL 3 tasks before time runs out
- OR vote out the Aswang in the voting phase

**Special Abilities:**
- None (but you have numbers!)

### 👹 YOU'RE THE ASWANG (1 player)
**Your Goal:** Kill all the villagers

**How to Win:**
- Eliminate all villagers (by getting close to them)
- OR survive all voting phases

**Special Abilities:**
- **Disguise** (30 sec) - Look like another player
- **Kill** - Get close to villagers to eliminate them

---

## 🎯 THE GAME IN 3 PHASES

### Phase 1: TASK PHASE (5 Minutes)
Everyone splits up to complete tasks around the barangay.

**Villagers:** Complete your 3 assigned tasks
```
🚰 Akyatin ang Kuryente (Fetch Electricity) → Barangay Hall
🍳 Lutuin ang Pagkain (Cook Food) → Sari-Sari Store
⚡ I-ayos ang Kuryente (Fix Electricity) → Poso (Well)
```

**How to complete a task:**
1. Walk to the task location
2. Stand on the glowing circle
3. Wait 30-45 seconds
4. ✓ Task completed!

**Aswang:** Hide and eliminate villagers
- Get close to any villager (collision = elimination)
- Use disguise to blend in
- Avoid being suspicious

**Fear System:** As time passes, villagers get scared
- Screen gets blurry
- Movement gets slower
- But it goes away when you complete tasks!

### Phase 2: TOWN MEETING (1 Minute)
Everyone meets at Barangay Hall to vote.

**What happens:**
1. Everyone gathers at the center
2. Discussion happens (chat)
3. Voting begins
4. Each player votes for someone they think is the Aswang
5. Most voted player is **eliminated**
6. Their role is **revealed**

**Strategy:**
- Villagers: Vote together
- Aswang: Vote for innocent players to cause chaos

### Phase 3: RESULTS
See who won!

**Villagers Win If:**
- All tasks completed, OR
- Aswang eliminated

**Aswang Wins If:**
- All villagers eliminated, OR
- Survives all voting phases

---

## 🕹️ CONTROLS

### Move
```
W = Up
A = Left
S = Down
D = Right

Or on mobile: Swipe to move
```

### Interact
```
Click Task = Complete task
Button = Call Meeting (start voting early)
Vote Button = Click on a player to vote them out
```

### With Game Controller
```
D-Pad = Move
A Button = Interact/Vote
X Button = Call Meeting
```

---

## 📍 THE MAP

```
Sari-Sari Store       Chapel
(Cook Food)            (Nothing)
      ↑                  ↑
      |                  |
Barangay Hall ←→ Basketball Court
(Fetch Power)          (Nothing)
      ↓
    Poso
  (Fix Power)
```

---

## 🎮 EXAMPLE GAME

### You're a Villager:

**Start:** You appear at Barangay Hall with 7 others

**See:** One player (the Aswang) but you don't know who yet

**Task 1:** Walk to Sari-Sari Store (top-left)
- Wait 30 seconds
- Task complete! ✓

**Task 2:** Walk to Barangay Hall (center)
- Wait 30 seconds
- Task complete! ✓

**Task 3:** Walk to Poso/Well (bottom)
- Suddenly a player rushes at you
- You get eliminated! 💀
- **Oh no! That was the Aswang!**

**Town Meeting:** (Your team votes)
- Other villager says "The person who was near Poso is sus!"
- Everyone votes for that player
- Vote passes
- **ASWANG ELIMINATED!**
- **VILLAGERS WIN!** 🎉

---

### You're the Aswang:

**Start:** You appear with 7 villagers (you know you're the Aswang)

**Your Plan:** 
- Watch who does tasks (they're safe while moving)
- Wait for someone to be alone
- Get close to eliminate them

**5 seconds in:** You see a villager walking alone to Sari-Sari Store

**You follow:** Get close to them
- **ELIMINATED!** They're out! 👹
- Their team doesn't know what happened yet

**Later:** Town meeting starts
- Villagers: "Who killed Player 3?"
- You: Vote for Player 4 (innocent)
- Creates confusion!

**Finally:** Villagers vote
- They vote for wrong person
- You survive!
- **ASWANG WINS!** 👹

---

## 🎯 BASIC STRATEGY

### For Villagers 👤

**DO:**
- Stick with teammates
- Complete tasks FAST
- Communicate in chat
- Vote together
- Watch for suspicious behavior

**DON'T:**
- Go alone
- Wander near edges
- Trust everyone
- Vote randomly
- Leave tasks unfinished

### For Aswang 👹

**DO:**
- Hide among the group
- Use disguise when needed
- Strike when they're alone
- Sow discord in chat
- Act innocent

**DON'T:**
- Kill near witnesses
- Stay near dead bodies
- Act too perfect
- Always disguise
- Reveal yourself early

---

## 💡 TIPS & TRICKS

### Everyone
- **Chat is your weapon** - Convince others of your position
- **Pay attention** - Who's where matters
- **Use time** - Voting phase happens at 5 minutes OR when called early
- **Stay calm** - Panicking gives you away

### Villagers
- **Work in groups of 2-3** - Safety in numbers
- **Assign tasks** - "You do water, I'll do electricity"
- **Remember roles** - Who was where?
- **Vote decisively** - Don't waste voting phase

### Aswang
- **Watch patterns** - Learn who goes where
- **Use fear** - Let villagers get paranoid
- **Timing** - Strike when they're isolated
- **Alibi** - Be seen doing "tasks"

---

## 🌙 GAME LENGTH

**Average game:** 6-8 minutes
- Task phase: 5 minutes (or until all done)
- Voting phase: 1 minute
- Results: 1 minute

---

## 🎊 WIN CONDITIONS

### Villagers Win ✓
```
1. Complete all 3 tasks before Aswang kills everyone
   OR
2. Vote out the Aswang in town meeting
```

### Aswang Wins ✓
```
1. Kill all 7 villagers
   OR
2. Survive all voting phases and eliminate everyone
```

### Draw
```
Time runs out before anything decided
(Rare - usually voting decides winner)
```

---

## 🎮 FIRST GAME CHECKLIST

Before you play:
- [ ] Understand the 2 roles (Villager vs Aswang)
- [ ] Know the 3 phases (Tasks → Meeting → Results)
- [ ] Learn the 3 tasks (Water, Cook, Power)
- [ ] Know the controls (WASD to move)
- [ ] Know how to vote (Click player)

That's it! You're ready! 🚀

---

## ❓ COMMON QUESTIONS

### Q: Can I see who the Aswang is?
**A:** Only if they get close to you (then you're eliminated!). Otherwise, no.

### Q: What if everyone is voted out?
**A:** Aswang wins. They were the last one standing.

### Q: Can I vote for myself?
**A:** No. The game prevents it.

### Q: What if there's a tie in voting?
**A:** No one is eliminated. Game continues.

### Q: Can I call an early meeting?
**A:** Yes! Click "CALL MEETING" button. Everyone goes to center.

### Q: What if a villager goes AFK?
**A:** They stay in game but just stand there. Easy target for Aswang.

### Q: Can the Aswang do tasks?
**A:** No. They don't need to. Their goal is elimination, not completion.

### Q: How long does disguise last?
**A:** 30 seconds. Then Aswang returns to normal appearance.

### Q: Can multiple Aswangs play?
**A:** No. Always exactly 1 Aswang per game.

---

## 🌟 FUN FACTS

- Based on Filipino folklore (Aswang = vampire monster)
- Works with 8 players for balance
- Fear system makes villagers paranoid
- Voting adds social deduction element
- Every game plays differently!

---

## 🎉 READY TO PLAY?

**Join a game and find out:** 

Are you the villager who survives the night? 

Or the Aswang who feasts? 

👹 **The night awaits...** 🌙

---

## 🔗 QUICK LINKS

- Create Room → Get 7 friends
- Join Room → Use room code
- Settings → Adjust game options

---

**First game is the best game. Go play!** 🎮

🌙 **Magandang Laro!** 👹
