// js/TouchControls.js
class TouchControls {
  constructor(scene) {
    this.scene = scene;
    this.keys = {
      w: false,
      a: false,
      s: false,
      d: false
    };
    
    this.touchPads = {};
    this.isSetup = false;
    
    this.init();
  }
  
  init() {
    // Touch movement detection
    document.addEventListener('touchstart', (e) => this.handleTouchStart(e), { passive: false });
    document.addEventListener('touchmove', (e) => this.handleTouchMove(e), { passive: false });
    document.addEventListener('touchend', (e) => this.handleTouchEnd(e), { passive: false });
    document.addEventListener('touchcancel', (e) => this.handleTouchCancel(e), { passive: false });
    
    // Keyboard as fallback
    document.addEventListener('keydown', (e) => this.handleKeyDown(e));
    document.addEventListener('keyup', (e) => this.handleKeyUp(e));
    
    // Gamepad support (iOS with controller)
    window.addEventListener('gamepadconnected', () => {
      console.log('[TOUCH] Gamepad connected');
      this.startGamepadPolling();
    });
    
    console.log('[TOUCH] Controls initialized');
  }
  
  handleTouchStart(e) {
    if (e.target.id === 'game' || e.target.tagName === 'CANVAS') {
      e.preventDefault();
    }
    
    for (let touch of e.touches) {
      const pos = this.getTouchPosition(touch);
      this.touchPads[touch.identifier] = {
        startX: pos.x,
        startY: pos.y,
        currentX: pos.x,
        currentY: pos.y,
        timestamp: Date.now()
      };
    }
  }
  
  handleTouchMove(e) {
    if (e.target.id === 'game' || e.target.tagName === 'CANVAS') {
      e.preventDefault();
    }
    
    for (let touch of e.touches) {
      if (this.touchPads[touch.identifier]) {
        const pos = this.getTouchPosition(touch);
        this.touchPads[touch.identifier].currentX = pos.x;
        this.touchPads[touch.identifier].currentY = pos.y;
      }
    }
    
    // Update movement based on swipe
    this.updateMovementFromTouches();
  }
  
  handleTouchEnd(e) {
    for (let touch of e.changedTouches) {
      delete this.touchPads[touch.identifier];
    }
    
    // Reset movement keys when no touches
    if (Object.keys(this.touchPads).length === 0) {
      this.keys.w = false;
      this.keys.a = false;
      this.keys.s = false;
      this.keys.d = false;
    }
  }
  
  handleTouchCancel(e) {
    for (let touch of e.changedTouches) {
      delete this.touchPads[touch.identifier];
    }
    
    this.keys.w = false;
    this.keys.a = false;
    this.keys.s = false;
    this.keys.d = false;
  }
  
  handleKeyDown(e) {
    const key = e.key.toLowerCase();
    if (key === 'w') this.keys.w = true;
    if (key === 'a') this.keys.a = true;
    if (key === 's') this.keys.s = true;
    if (key === 'd') this.keys.d = true;
  }
  
  handleKeyUp(e) {
    const key = e.key.toLowerCase();
    if (key === 'w') this.keys.w = false;
    if (key === 'a') this.keys.a = false;
    if (key === 's') this.keys.s = false;
    if (key === 'd') this.keys.d = false;
  }
  
  updateMovementFromTouches() {
    // Reset
    this.keys.w = false;
    this.keys.a = false;
    this.keys.s = false;
    this.keys.d = false;
    
    // Check each touch
    for (let touchId in this.touchPads) {
      const pad = this.touchPads[touchId];
      const deltaX = pad.currentX - pad.startX;
      const deltaY = pad.currentY - pad.startY;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      
      // Dead zone: 10px
      if (distance > 10) {
        const angle = Math.atan2(deltaY, deltaX);
        const degrees = angle * (180 / Math.PI);
        
        // Determine direction based on angle
        // 0° = right, 90° = down, -90° = up, 180° = left
        if (degrees > -45 && degrees < 45) {
          // Right
          this.keys.d = true;
        } else if (degrees > 45 && degrees < 135) {
          // Down
          this.keys.s = true;
        } else if (degrees < -45 && degrees > -135) {
          // Up
          this.keys.w = true;
        } else {
          // Left
          this.keys.a = true;
        }
      }
    }
  }
  
  getTouchPosition(touch) {
    const canvas = this.scene.game.canvas;
    const rect = canvas.getBoundingClientRect();
    
    return {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    };
  }
  
  startGamepadPolling() {
    setInterval(() => this.pollGamepad(), 100);
  }
  
  pollGamepad() {
    const gamepads = navigator.getGamepads();
    
    for (let gamepad of gamepads) {
      if (!gamepad) continue;
      
      // D-Pad or analog stick
      const axes = gamepad.axes;
      
      // Left analog stick
      if (Math.abs(axes[0]) > 0.5) {
        // Horizontal
        this.keys.d = axes[0] > 0.5;
        this.keys.a = axes[0] < -0.5;
      }
      
      if (Math.abs(axes[1]) > 0.5) {
        // Vertical
        this.keys.s = axes[1] > 0.5;
        this.keys.w = axes[1] < -0.5;
      }
      
      // Check buttons for actions
      if (gamepad.buttons[0].pressed) {
        // A button - interact/vote
        this.scene.events.emit('action-button');
      }
      
      if (gamepad.buttons[2].pressed) {
        // X button - call meeting
        this.scene.events.emit('vote-button');
      }
    }
  }
  
  isMovingUp() { return this.keys.w; }
  isMovingDown() { return this.keys.s; }
  isMovingLeft() { return this.keys.a; }
  isMovingRight() { return this.keys.d; }
  
  isMoving() {
    return this.keys.w || this.keys.s || this.keys.a || this.keys.d;
  }
  
  getDirection() {
    let x = 0;
    let y = 0;
    
    if (this.keys.d) x += 1;
    if (this.keys.a) x -= 1;
    if (this.keys.s) y += 1;
    if (this.keys.w) y -= 1;
    
    // Normalize diagonal movement
    if (x !== 0 && y !== 0) {
      const len = Math.sqrt(x * x + y * y);
      x /= len;
      y /= len;
    }
    
    return { x, y };
  }
  
  destroy() {
    document.removeEventListener('touchstart', this.handleTouchStart.bind(this));
    document.removeEventListener('touchmove', this.handleTouchMove.bind(this));
    document.removeEventListener('touchend', this.handleTouchEnd.bind(this));
  }
}

// Export for use
window.TouchControls = TouchControls;
console.log('[TOUCH] TouchControls module loaded');
