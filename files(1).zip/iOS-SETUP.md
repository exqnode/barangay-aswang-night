# 🍎 iOS SETUP GUIDE - Barangay: Aswang Night

**Two ways to get your game on iOS:**
1. **PWA** (Easiest) - 5 minutes, runs in Safari
2. **Native App** (Better) - 20 minutes, deploy to App Store

---

## ⚡ OPTION 1: PWA (Progressive Web App) - 5 MINUTES

### What is a PWA?
- Installs as app on iOS home screen
- Works offline
- No App Store submission needed
- Updates automatically

### Step 1: Update Your Project Files

```bash
cd barangay-aswang-night/client

# Copy PWA files
cp ../manifest.json .
cp ../service-worker.js .
cp ../index-pwa.html index.html
cp ../js-TouchControls.js js/TouchControls.js
```

### Step 2: Update GameScene.js

Add touch controls to your GameScene.js:

```javascript
// In GameScene.js create() method, add:

this.touchControls = new TouchControls(this);

// Then in update() method, replace keyboard handling with:
const direction = this.touchControls.getDirection();
if (Math.abs(direction.x) > 0.1 || Math.abs(direction.y) > 0.1) {
  // Player is moving
  const speed = 150;
  this.player.x += direction.x * speed * this.time.deltaTime / 1000;
  this.player.y += direction.y * speed * this.time.deltaTime / 1000;
}
```

### Step 3: Test Locally First

```bash
# Terminal 1: Start server
npm start

# Terminal 2: Start client
cd client
npx http-server -p 8080

# Test at http://localhost:8080
```

### Step 4: Deploy to Free Hosting

#### Deploy Backend to Render.com

1. Go to [render.com](https://render.com)
2. Create new "Web Service"
3. Connect your GitHub repo
4. Settings:
   ```
   Build Command: npm install
   Start Command: node server.js
   Environment: Node
   ```
5. Add ENV var: `CLIENT_URL=https://your-app.vercel.app`
6. Deploy!

**Get your backend URL** (e.g., `https://aswang-server.onrender.com`)

#### Deploy Frontend to Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Select your GitHub repo
4. Settings:
   ```
   Framework: Other
   Root: client
   ```
5. Add ENV var: `REACT_APP_SERVER_URL=https://aswang-server.onrender.com`
6. Deploy!

**Get your frontend URL** (e.g., `https://aswang-night.vercel.app`)

### Step 5: Install on iOS

#### On your iPhone/iPad:

1. **Safari**: Go to your Vercel URL (https://aswang-night.vercel.app)

2. **Share button** (bottom center)

3. **"Add to Home Screen"**

4. **Name it**: "Aswang Night"

5. **Done!** App now appears on home screen

### Step 6: Open and Test

- Tap the app icon on home screen
- Game opens fullscreen (no Safari UI)
- Touch to move
- Tap buttons to interact

### 🎮 Touch Controls on iOS

```
Left side of screen: Swipe to move character
Right side: Tap buttons for actions
- READY / VOTE / CALL MEETING buttons
```

---

## 🏗️ OPTION 2: Native iOS App with Capacitor - 20 MINUTES

### What is Capacitor?
- Wraps web app as native iOS app
- Access to camera, location, notifications
- Deploy to App Store
- One codebase for iOS, Android, Web

### Prerequisites
```bash
# Install Node.js 16+
node --version

# Install iOS build tools (Mac only)
xcode-select --install

# Install CocoaPods
sudo gem install cocoapods
```

### Step 1: Setup Capacitor

```bash
cd barangay-aswang-night

# Install Capacitor CLI & core
npm install --save @capacitor/core @capacitor/cli

# Initialize Capacitor
npx cap init

# When prompted:
App name: Barangay Aswang Night
App ID: com.barangay.aswangnight
```

### Step 2: Install iOS Platform

```bash
# Add iOS support
npx cap add ios

# This creates ios/ folder with Xcode project
```

### Step 3: Build Web Assets

```bash
# Make sure client files are in the right place
# For Capacitor, web assets go in www/ folder

mkdir -p www
cp -r client/* www/
```

### Step 4: Sync to iOS

```bash
# Copy web assets to Xcode project
npx cap sync ios

# This updates the iOS project with your latest code
```

### Step 5: Open in Xcode

```bash
# Open Xcode project
npx cap open ios

# Or manually:
open ios/App/App.xcworkspace
```

### Step 6: Configure in Xcode

1. **Select "App" in Project Navigator** (left side)
2. **General tab:**
   - Bundle ID: `com.barangay.aswangnight`
   - Version: `1.0.0`
   - Build: `1`
   - Minimum Deployments: `iOS 13.0`

3. **Signing & Capabilities:**
   - Team: Select your Apple Developer account (free)
   - Enable "Capability: Push Notifications" (optional)

4. **Build Settings:**
   - Product Name: `Aswang Night`
   - Bundle Display Name: `Aswang Night`

### Step 7: Test on Simulator

```bash
# In Xcode: Select iPhone simulator
# Product menu → Run
# Or press Cmd + R
```

Game will launch in simulator!

### Step 8: Test on Real Device (Free)

1. **Connect iPhone via USB**
2. **Xcode: Select your device** (top toolbar)
3. **Product → Run** (Cmd + R)
4. **Trust the app** on device settings

**Done!** App runs on your phone!

### Step 9: Build for App Store (Optional)

```bash
# In Xcode: Product → Archive

# Select App Store distribution
# Sign with your Apple Developer account

# Submit to App Store Connect (app-store-connect.apple.com)
```

---

## 📱 FILE STRUCTURE FOR iOS

```
barangay-aswang-night/
├── server.js
├── package.json
├── manifest.json          ← PWA config
├── service-worker.js      ← PWA offline
├── capacitor.config.json  ← Capacitor config (auto-created)
├── www/                   ← Web assets (for Capacitor)
│   ├── index.html
│   ├── service-worker.js
│   ├── manifest.json
│   ├── js/
│   └── assets/
├── client/                ← Web version
│   ├── index.html
│   ├── manifest.json
│   ├── service-worker.js
│   ├── js/
│   │   ├── TouchControls.js  ← NEW for iOS
│   │   ├── main.js
│   │   └── ...
│   └── assets/
└── ios/                   ← Native iOS project (Capacitor)
    └── App/App.xcworkspace
```

---

## 🔧 CAPACITOR CONFIGURATION

### capacitor.config.json

```json
{
  "appId": "com.barangay.aswangnight",
  "appName": "Aswang Night",
  "webDir": "www",
  "plugins": {
    "SplashScreen": {
      "launchShowDuration": 2000,
      "backgroundColor": "#1a1a2e"
    }
  },
  "ios": {
    "contentInset": "automatic",
    "limitsNavigationsToAppBoundDomains": false
  }
}
```

### iOS Specific Settings

```json
{
  "ios": {
    "UIStatusBarStyle": "Light",
    "StatusBarBackgroundColor": "#1a1a2e",
    "StatusBarOverlayWebView": false,
    "limitsNavigationsToAppBoundDomains": false,
    "preferredContentMode": "mobile"
  }
}
```

---

## 🚀 DEPLOYMENT STRATEGIES

### PWA (Recommended for Quick Launch)
- ✅ 5 minutes to iOS
- ✅ No App Store review
- ✅ Instant updates
- ✅ Works on all platforms
- ❌ Not in App Store
- ❌ Limited native features

### Capacitor (Recommended for Long Term)
- ✅ In App Store
- ✅ Native features
- ✅ Offline support
- ✅ Professional appearance
- ❌ 20+ minutes setup
- ❌ App Store review (1-2 days)

### Hybrid Strategy
1. **Start with PWA**: Get users immediately
2. **Build native with Capacitor**: Launch App Store version
3. **Keep both**: PWA for web, App for app store

---

## 📋 QUICK REFERENCE

### PWA Deployment Checklist

```
□ Copy manifest.json to project
□ Copy service-worker.js to project
□ Update index.html with PWA meta tags
□ Add TouchControls.js to js/ folder
□ Test locally (http://localhost:8080)
□ Deploy backend to Render.com
□ Deploy frontend to Vercel
□ Test on iOS Safari
□ Add to Home Screen
□ Play!
```

### Capacitor Deployment Checklist

```
□ npm install @capacitor/core @capacitor/cli
□ npx cap init
□ npx cap add ios
□ mkdir -p www && cp -r client/* www/
□ npx cap sync ios
□ npx cap open ios
□ Configure Xcode (Team, Bundle ID)
□ Test on simulator (Cmd + R)
□ Test on real device (connect iPhone)
□ Archive for App Store (optional)
```

---

## 🐛 TROUBLESHOOTING

### PWA Not Installing on iOS

**Solution 1: Clear Safari Cache**
```
Settings → Safari → Clear History and Website Data
```

**Solution 2: Check manifest.json**
```
- Must be valid JSON
- Must be in root of web server
- Must be linked in <head> with <link rel="manifest">
```

**Solution 3: HTTPS Required**
```
- PWA only works on HTTPS (except localhost)
- Vercel provides free HTTPS
```

### "Cannot Connect to Server" on iOS

```bash
# 1. Check server is running on Render
# Go to: https://aswang-server.onrender.com/api/health
# Should return JSON

# 2. Update CLIENT_URL in Vercel
# Project Settings → Environment Variables
# CLIENT_URL = your-server-url

# 3. Test connection
# Open browser console (F12)
# Should show "[SOCKET] Player connected"
```

### Capacitor Build Fails

```bash
# Clean build
rm -rf ios
npx cap add ios

# Re-sync
npx cap sync ios

# In Xcode: Product → Clean Build Folder (Shift + Cmd + K)
```

### App Crashes on iOS

```bash
# Check Xcode console for errors
# Product → Scheme → Edit Scheme → Run → Console

# Common issues:
# 1. Missing permissions in Info.plist
# 2. Socket.IO connection timeout
# 3. Missing JavaScript files

# Enable debugging:
# Xcode → Debug → View Debug Hierarchy
```

---

## 📞 SUPPORT

### For PWA Issues
- Check browser console (F12 → Console)
- Verify manifest.json is valid (jsonlint.com)
- Ensure HTTPS on production

### For Capacitor Issues
- Check Xcode console output
- Verify iOS deployment target is 13.0+
- Check pods are installed: `cd ios/App && pod install`

### Common Ports

```
Local dev:
- Server: http://localhost:5000
- Client: http://localhost:8080

Production:
- Server: https://aswang-server.onrender.com
- Client: https://aswang-night.vercel.app
```

---

## 🎮 CONTROLS ON iOS

### Touch
```
Left swipe/drag: Move up
Right swipe/drag: Move right
Down swipe/drag: Move down
Left swipe/drag: Move left

Tap buttons: READY, VOTE, CALL MEETING
```

### With Controller (Capacitor)
```
D-Pad: Move
A Button: Interact/Vote
X Button: Call Meeting
```

---

## 🚀 NEXT STEPS

### Path 1: Quick PWA Launch (Today)
1. Update files (5 min)
2. Deploy to Render + Vercel (5 min)
3. Test on iOS Safari (2 min)
4. Share with friends!

### Path 2: Native App (This Week)
1. Setup Capacitor (10 min)
2. Build & test on simulator (5 min)
3. Test on real device (5 min)
4. Submit to App Store (24-48h review)

### Path 3: Both (Professional)
1. Keep PWA live for immediate access
2. Build Capacitor for App Store
3. Users can choose: PWA or App Store

---

## ✨ FEATURES ENABLED ON iOS

### PWA Features
- ✅ Offline support (via service worker)
- ✅ Home screen icon
- ✅ Fullscreen mode
- ✅ Touch controls
- ✅ Status bar integration

### Capacitor Extra Features (App Store)
- ✅ All PWA features
- ✅ App Store presence
- ✅ Native notifications
- ✅ Camera access (if added)
- ✅ Location access (if added)
- ✅ Better memory management

---

## 💰 COST BREAKDOWN

| Platform | Cost | Setup Time |
|----------|------|-----------|
| **PWA** | FREE | 5 min |
| **Capacitor** | FREE (dev) | 20 min |
| **App Store** | $99/year | 1 min |
| **Total** | $99/year (optional) | 20-25 min |

---

## 🎉 YOU'RE READY!

**Choose your path:**

### 👉 **Option 1: PWA (Easiest)**
1. Follow PWA steps above
2. Deploy to Vercel
3. Add to home screen on iPhone
4. Play today!

### 👉 **Option 2: Native (Best)**
1. Follow Capacitor steps
2. Test on simulator
3. Deploy to App Store
4. Share with world!

---

**Need help? Check the troubleshooting section above or review the README.md for general game help.**

🌙 **Magandang Laro sa iOS!** 👹
