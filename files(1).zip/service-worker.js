// service-worker.js
const CACHE_NAME = 'aswang-night-v1';
const RUNTIME_CACHE = 'aswang-runtime-v1';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/js/main.js',
  '/js/BootScene.js',
  '/js/GameScene.js',
  '/js/SocketManager.js',
  '/js/GameLogic.js',
  '/js/UIManager.js',
  '/js/FearSystem.js',
  '/js/entities/Player.js',
  '/js/entities/Map.js'
];

// Install: Cache static assets
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker');
  
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Caching static assets');
      // Don't fail if some assets are missing - graceful degradation
      return Promise.allSettled(
        STATIC_ASSETS.map(asset => cache.add(asset).catch(err => {
          console.warn(`[SW] Failed to cache ${asset}`, err);
        }))
      );
    }).then(() => self.skipWaiting())
  );
});

// Activate: Clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch: Serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Only handle GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip third-party requests (CDNs, APIs)
  if (!url.origin.includes(self.location.origin)) {
    // For third-party APIs, try network with fallback
    event.respondWith(
      fetch(request)
        .then(response => {
          // Don't cache API responses
          return response;
        })
        .catch(() => {
          // Offline fallback for APIs
          return new Response(
            JSON.stringify({ error: 'offline', cached: false }),
            { 
              status: 503,
              headers: { 'Content-Type': 'application/json' }
            }
          );
        })
    );
    return;
  }
  
  // For local assets: Cache first, fallback to network
  event.respondWith(
    caches.match(request).then((response) => {
      if (response) {
        console.log('[SW] Serving from cache:', request.url);
        return response;
      }
      
      return fetch(request).then((response) => {
        // Only cache successful responses
        if (!response || response.status !== 200 || response.type === 'error') {
          return response;
        }
        
        // Cache successful responses
        const responseToCache = response.clone();
        caches.open(RUNTIME_CACHE).then((cache) => {
          cache.put(request, responseToCache);
        });
        
        return response;
      }).catch((error) => {
        console.error('[SW] Fetch failed:', request.url, error);
        
        // Return offline page for HTML requests
        if (request.headers.get('accept')?.includes('text/html')) {
          return caches.match('/index.html');
        }
        
        // Return empty response for other types
        return new Response('Offline - no cached version available', {
          status: 503,
          statusText: 'Service Unavailable'
        });
      });
    })
  );
});

// Handle messages from clients
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    caches.delete(CACHE_NAME).then(() => {
      caches.delete(RUNTIME_CACHE).then(() => {
        console.log('[SW] Caches cleared');
      });
    });
  }
});

// Periodic background sync (iOS 16.1+)
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-game-state') {
    event.waitUntil(syncGameState());
  }
});

async function syncGameState() {
  try {
    const response = await fetch('/api/sync');
    return response.json();
  } catch (error) {
    console.error('[SW] Sync failed:', error);
  }
}

console.log('[SW] Service Worker loaded');
