# 🍎 iOS IMPLEMENTATION GUIDE - COPY & PASTE SETUP

**Make your Barangay: Aswang Night game work on iOS in one sitting.**

Status: **PRODUCTION READY**  
Time: **5-30 minutes** (PWA or Native)  
Cost: **FREE** (or $99/year for App Store)

---

## 🚀 QUICKSTART: 5 MINUTES TO iOS (PWA)

### Step 1: Copy PWA Files to Your Project

```bash
# Navigate to your project
cd barangay-aswang-night

# Create client directory if needed
mkdir -p client/js

# Copy these files to client/:
# - manifest.json
# - service-worker.js
# - index-pwa.html (rename to index.html)
# - TouchControls.js (to client/js/)
```

### Step 2: Update Your Client Folder

```bash
# Download files (from this guide)
# Put them in these locations:

client/
├── manifest.json              ← PWA config
├── service-worker.js          ← Offline support
├── index.html                 ← Updated with PWA meta tags
└── js/
    └── TouchControls.js       ← iOS touch controls
```

### Step 3: Update GameScene.js

Add this to your GameScene class:

```javascript
// In GameScene.js - around line 20 in create()
create() {
  // ... existing code ...
  
  // NEW: Initialize touch controls
  this.touchControls = new TouchControls(this);
  
  // ... rest of create ...
}

// In update() method, replace keyboard input section with:
update() {
  // ... existing code ...
  
  // NEW: Get movement from touch/keyboard
  const direction = this.touchControls.getDirection();
  
  if (Math.abs(direction.x) > 0.05 || Math.abs(direction.y) > 0.05) {
    const speed = 150; // pixels per second
    const moveX = direction.x * speed * this.time.deltaTime / 1000;
    const moveY = direction.y * speed * this.time.deltaTime / 1000;
    
    // Move player with collision
    this.player.x += moveX;
    this.player.y += moveY;
    
    // Keep player in bounds
    this.player.x = Phaser.Math.Clamp(this.player.x, 0, 1024);
    this.player.y = Phaser.Math.Clamp(this.player.y, 0, 768);
    
    // Emit movement to server
    if (socketManager && socketManager.socket) {
      socketManager.emitPlayerMove(this.player.x, this.player.y);
    }
  }
  
  // ... rest of update ...
}
```

### Step 4: Test Locally

```bash
# Terminal 1: Start server
npm start
# Expected: "Server running on port 5000"

# Terminal 2: Start client
cd client
npx http-server -p 8080
# Expected: "Hit CTRL-C to stop the server"

# Browser: Open http://localhost:8080
# Mobile: Open http://<YOUR_IP>:8080
```

**YOUR_IP** = Find with:
- Mac: `ipconfig getifaddr en0`
- Linux: `hostname -I`
- Windows: `ipconfig` (look for IPv4)

### Step 5: Deploy for Free

#### Option A: Render.com (Backend)

1. Go to [render.com](https://render.com) → Sign up
2. Click "New" → "Web Service"
3. Connect GitHub (fork repo first if needed)
4. **Settings:**
   ```
   Name: aswang-server
   Environment: Node
   Build Command: npm install
   Start Command: npm start
   ```
5. **Environment Variables:**
   ```
   PORT=5000
   NODE_ENV=production
   CLIENT_URL=https://aswang-night.vercel.app
   ```
6. Click "Create Web Service"
7. **Wait 3-5 min for deployment**
8. **Copy backend URL** (like `https://aswang-server.onrender.com`)

#### Option B: Vercel (Frontend)

1. Go to [vercel.com](https://vercel.com) → Sign up
2. Click "Add New" → "Project"
3. Select your GitHub repo
4. **Settings:**
   ```
   Framework: Other (No framework)
   Root Directory: client
   Build Command: (leave empty)
   Start Command: (leave empty)
   ```
5. **Environment Variables:**
   ```
   REACT_APP_SERVER_URL=https://aswang-server.onrender.com
   ```
6. Click "Deploy"
7. **Wait 2-3 min for deployment**
8. **Copy frontend URL** (like `https://aswang-night.vercel.app`)

### Step 6: Update Client to Use Production Server

Edit `client/js/SocketManager.js`:

```javascript
// Find this line (around line 30):
async connect(serverUrl) {
  // CHANGE THIS:
  // FROM:
  // const url = serverUrl || 'http://localhost:5000';
  
  // TO:
  const url = serverUrl || 'https://aswang-server.onrender.com';
  
  this.socket = io(url, {
    // ... rest of config
  });
}
```

Redeploy Vercel:
```bash
git push origin main
# Vercel auto-redeploys
```

### Step 7: Install on iOS (Safari)

1. **Open Safari on iPhone/iPad**
2. **Go to:** https://aswang-night.vercel.app
3. **Tap Share button** (bottom center, ⬆️ icon)
4. **Tap "Add to Home Screen"**
5. **Name:** "Aswang Night" (or leave as is)
6. **Tap "Add"**
7. **Done!** Tap the icon to play

---

## 🏗️ NATIVE iOS APP: 20 MINUTES (CAPACITOR)

### Prerequisites

```bash
# Check Node version (need 16+)
node --version

# On Mac: Install Xcode command line tools
xcode-select --install

# Install CocoaPods (for iOS)
sudo gem install cocoapods
```

### Step 1: Install Capacitor

```bash
cd barangay-aswang-night

# Install Capacitor packages
npm install --save @capacitor/core @capacitor/cli

# Initialize (when prompted, press Enter to use defaults)
npx cap init

# You'll see prompts:
# App name: Barangay Aswang Night
# App ID: com.barangay.aswangnight
# Folder: . (current directory)
```

### Step 2: Prepare Web Assets

```bash
# Create www folder with web files
mkdir -p www/js/scenes www/js/entities

# Copy files (update paths as needed)
cp client/index.html www/
cp client/manifest.json www/
cp client/service-worker.js www/
cp client/js/*.js www/js/
cp -r client/js/scenes/* www/js/scenes/
cp -r client/js/entities/* www/js/entities/
```

### Step 3: Add iOS Platform

```bash
# This creates the ios/ folder with Xcode project
npx cap add ios

# Expected output:
# ✔ Created ios/App/App.xcworkspace
```

### Step 4: Sync Code to iOS Project

```bash
# Copy web assets to Xcode project
npx cap sync ios

# Expected output:
# ✔ Copied web assets to ios/App/public
```

### Step 5: Open in Xcode

```bash
# Open Xcode project
npx cap open ios

# Or manually:
open ios/App/App.xcworkspace
```

**IMPORTANT:** Open `.xcworkspace` not `.xcodeproj`

### Step 6: Configure Xcode

1. **Project Navigator:** Click "App" (left sidebar)
2. **Select "App" target**
3. **General tab:**
   - Display Name: `Aswang Night`
   - Bundle Identifier: `com.barangay.aswangnight`
   - Version: `1.0.0`
   - Build: `1`
   - Minimum Deployments: `iOS 13.0` or higher

4. **Signing & Capabilities:**
   - **Team:** Select your Apple ID (free)
   - If no team: "Add Account" with Apple ID

5. **Build Settings:**
   - Search: "Product Name"
   - Set to: `Aswang Night`

### Step 7: Run on Simulator (5 min)

```bash
# In Xcode: Select a simulator at top
# Example: "iPhone 14 Pro"

# Product menu → Run
# Or press: Cmd + R

# Wait 30-60 seconds for build

# Game launches in simulator!
```

### Step 8: Run on Real iPhone (10 min)

```bash
# 1. Connect iPhone via USB cable
# 2. Trust the computer when prompted on iPhone
# 3. In Xcode: Select your iPhone (top toolbar)
# 4. Product → Run (Cmd + R)
# 5. Wait for build (2-3 minutes first time)
# 6. App appears on home screen
# 7. Tap app icon to play!
```

### Step 9: (Optional) Submit to App Store

```bash
# In Xcode:
# 1. Product → Archive
# 2. Distribute App
# 3. Select "App Store Connect"
# 4. Sign with your Apple Developer account
# 5. Upload
# 6. Wait 1-2 days for review

# Cost: $99/year for Developer account
```

---

## 📁 FINAL PROJECT STRUCTURE

```
barangay-aswang-night/
│
├── 📄 server.js                    (Backend)
├── 📄 GameRoom.js
├── 📄 constants.js
├── 📄 package.json
├── 📄 .env.example
│
├── 📄 manifest.json                (PWA Config)
├── 📄 service-worker.js            (PWA Offline)
├── 📄 capacitor.config.json        (Capacitor Config)
├── 📄 iOS-SETUP.md                 (This guide)
│
├── 📁 client/                      (Web Version)
│   ├── 📄 index.html
│   ├── 📄 manifest.json
│   ├── 📄 service-worker.js
│   ├── 📁 js/
│   │   ├── 📄 main.js
│   │   ├── 📄 TouchControls.js     (NEW for iOS)
│   │   ├── 📄 GameScene.js         (UPDATED)
│   │   └── ... other files
│   └── 📁 assets/
│
├── 📁 www/                         (Capacitor Web Assets)
│   ├── 📄 index.html
│   └── 📁 js/
│
└── 📁 ios/                         (Native iOS Project - Capacitor)
    └── 📁 App/
        └── 📄 App.xcworkspace      ← Open this in Xcode!
```

---

## ✅ VERIFICATION CHECKLIST

### PWA Setup
- [ ] manifest.json in client/
- [ ] service-worker.js in client/
- [ ] index.html has PWA meta tags
- [ ] TouchControls.js in client/js/
- [ ] GameScene.js updated with touch handling
- [ ] Server running on localhost:5000
- [ ] Client running on localhost:8080
- [ ] Backend deployed to Render.com
- [ ] Frontend deployed to Vercel
- [ ] Deployed URL works in browser
- [ ] "Add to Home Screen" works on iOS

### Capacitor Setup
- [ ] Node 16+ installed
- [ ] Xcode installed (Mac only)
- [ ] CocoaPods installed
- [ ] Capacitor CLI installed
- [ ] capacitor.config.json created
- [ ] www/ folder created with assets
- [ ] ios/ folder created
- [ ] Xcode project opens
- [ ] Team/Signing configured
- [ ] Simulator builds successfully
- [ ] Real device builds successfully

---

## 🐛 QUICK TROUBLESHOOTING

### "Cannot find manifest.json"
```bash
# Make sure manifest.json is in the same folder as index.html
ls -la client/manifest.json
# Should exist
```

### "Service worker won't register"
```bash
# HTTPS required (except localhost)
# Make sure you're using HTTPS URL on production
# Vercel provides free HTTPS
```

### Capacitor: "No such module @capacitor/core"
```bash
npm install --save @capacitor/core @capacitor/cli
rm -rf ios
npx cap add ios
```

### Xcode: "Failed to build"
```bash
# Clean Xcode
# Product → Clean Build Folder (Shift + Cmd + K)

# Clean pods
cd ios/App
rm -rf Pods
rm Podfile.lock
pod install
```

### iPhone won't run app
```bash
# 1. Disconnect and reconnect iPhone
# 2. Trust computer on iPhone (Settings → Developer)
# 3. Clear Xcode cache: rm -rf ~/Library/Developer/Xcode/DerivedData
# 4. Try again: Cmd + R
```

---

## 📊 DEPLOYMENT COMPARISON

| Method | Setup Time | Cost | Updates | Distribution |
|--------|-----------|------|---------|---|
| **PWA** | 5 min | Free | Instant | Share link |
| **Capacitor (Dev)** | 20 min | Free | Manual | USB only |
| **Capacitor (App Store)** | 30 min | $99/yr | 1-2 days | App Store |

---

## 🎮 TESTING ON iOS

### PWA Testing
1. Open Safari
2. Navigate to deployed URL
3. Use "Add to Home Screen"
4. Play directly!

### App Testing
1. Connect iPhone
2. Xcode → Select device
3. Product → Run (Cmd + R)
4. Watch console for errors
5. Test on device

### What to Test
- [ ] Game loads
- [ ] Touch movement works
- [ ] Buttons respond to taps
- [ ] Game connects to server
- [ ] Player sync works
- [ ] Tasks complete
- [ ] Voting works
- [ ] Results show

---

## 🚀 RECOMMENDED PATH

### For Quick Launch (Today)
1. **PWA Setup** (5 min)
2. **Deploy to Vercel** (5 min)
3. **Add to Home Screen** (1 min)
4. **Play with friends!**

### For Professional Release (This Week)
1. **Setup Capacitor** (20 min)
2. **Test on simulator** (10 min)
3. **Test on real device** (5 min)
4. **Submit to App Store** (1 min)
5. **Wait 1-2 days for review**

### For Maximum Reach (Long Term)
1. **Keep PWA live** (instant, no review)
2. **Release app on App Store** (reviewed, polished)
3. **Track analytics** (see which users prefer)

---

## 💡 PRO TIPS

### For PWA
- Users don't need App Store
- Updates are instant
- Works on all platforms
- Best for rapid iteration

### For Native App
- Users find it on App Store
- More professional feel
- Better offline support
- Eligible for features like notifications

### Hybrid Strategy
- Deploy PWA first (today)
- Build native later (next week)
- Users can choose their preference
- Same codebase for both!

---

## 📱 TOUCH CONTROLS ON iOS

### Without Controller
```
Left side: Drag up = Move up
           Drag left = Move left
           Drag down = Move down
           Drag right = Move right

Right side: Tap buttons for actions
```

### With Game Controller
```
D-Pad: Move (4 directions)
A Button: Interact/Vote
X Button: Call Meeting
```

---

## 🎯 NEXT STEPS

### Now
1. Choose PWA or Capacitor
2. Copy files to project
3. Run setup commands

### In 5 Minutes (PWA)
1. Deploy to Vercel
2. Add to home screen
3. Play!

### In 20 Minutes (Capacitor)
1. Setup in Xcode
2. Test on simulator
3. Test on device
4. Submit to App Store (optional)

---

## 📞 NEED HELP?

### Common Issues
1. **"Port already in use"** → Use different port: `PORT=5001 npm start`
2. **"Cannot connect to server"** → Check Render.com deployed URL
3. **"Service worker won't install"** → HTTPS required (except localhost)
4. **"Xcode build fails"** → Clean build: Shift + Cmd + K

### Resources
- [PWA Docs](https://web.dev/progressive-web-apps/)
- [Capacitor Docs](https://capacitorjs.com/)
- [Vercel Docs](https://vercel.com/docs)
- [Render Docs](https://render.com/docs)

---

## ✨ YOU'RE READY!

**Pick one path and follow it. You'll have your game on iOS in one session.**

### 👉 PWA: Fast Track
```bash
1. Copy manifest.json, service-worker.js
2. Update index.html
3. Deploy to Vercel
4. Add to home screen
```

### 👉 Capacitor: Professional
```bash
1. npm install @capacitor/core @capacitor/cli
2. npx cap init && npx cap add ios
3. npx cap open ios
4. Configure and deploy
```

---

## 🎉 DEPLOY TIME!

**You have everything you need. Go launch your game on iOS today!**

🌙 **Magandang Laro!** 👹

---

**Questions? Errors? Check the troubleshooting section or re-read the step that failed. Most issues have simple solutions!**
