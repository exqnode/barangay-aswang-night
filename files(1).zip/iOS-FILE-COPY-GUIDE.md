# 📋 iOS FILE COPY GUIDE - Exact Commands

**Copy-paste these commands to add iOS support to your game.**

---

## ⚡ QUICKEST PATH (5 MINUTES)

### Step 1: Prepare Your Project

```bash
# Navigate to your project root
cd barangay-aswang-night

# Create necessary directories if missing
mkdir -p client/js
mkdir -p www
```

### Step 2: Copy PWA Files

```bash
# Copy all PWA files to client folder
cp manifest.json client/
cp service-worker.js client/
cp index-pwa.html client/index.html    # Rename!
cp js-TouchControls.js client/js/TouchControls.js
```

### Step 3: Copy Capacitor Config

```bash
# Copy Capacitor configuration to project root
cp capacitor.config.json .
```

### Step 4: Update package.json Scripts

Replace your package.json scripts section with the iOS-compatible version:

```bash
# View current package.json
cat package.json

# Update with iOS scripts (see package-ios.json)
# Or manually add these scripts:
# "capacitor:init": "npm install --save @capacitor/core @capacitor/cli && npx cap init"
# "capacitor:add-ios": "npx cap add ios"
# "capacitor:sync": "npm run build:web && npx cap sync ios"
```

### Step 5: Verify Files Are in Place

```bash
# Check all files are copied
ls -la client/manifest.json
ls -la client/service-worker.js
ls -la client/index.html
ls -la client/js/TouchControls.js
ls -la capacitor.config.json

# Should all return file paths (no errors)
```

### Step 6: Update GameScene.js

Open `client/js/GameScene.js` and find the `create()` method around line 20:

**ADD this line after existing code:**
```javascript
// NEW: Initialize touch controls
this.touchControls = new TouchControls(this);
```

**In the `update()` method, ADD this code:**
```javascript
// NEW: Get movement from touch/keyboard
const direction = this.touchControls.getDirection();

if (Math.abs(direction.x) > 0.05 || Math.abs(direction.y) > 0.05) {
  const speed = 150;
  const moveX = direction.x * speed * this.time.deltaTime / 1000;
  const moveY = direction.y * speed * this.time.deltaTime / 1000;
  
  this.player.x += moveX;
  this.player.y += moveY;
  
  // Keep in bounds
  this.player.x = Phaser.Math.Clamp(this.player.x, 0, 1024);
  this.player.y = Phaser.Math.Clamp(this.player.y, 0, 768);
  
  // Sync with server
  if (socketManager && socketManager.socket) {
    socketManager.emitPlayerMove(this.player.x, this.player.y);
  }
}
```

### Step 7: Test Locally

```bash
# Terminal 1: Start server
npm start
# Wait for: "Server running on port 5000"

# Terminal 2: Start client
cd client
npx http-server -p 8080
# Wait for HTTP server message

# Browser: http://localhost:8080
# Phone: http://<YOUR_IP>:8080
```

**Done!** Your game now works with touch on iOS browsers!

---

## 🍎 DEPLOY TO iOS (PWA) - 10 MINUTES

### Step 8: Deploy Backend

```bash
# 1. Create GitHub account (if not already)
# 2. Fork/push your repo to GitHub
git add .
git commit -m "Add iOS support"
git push origin main

# 3. Go to https://render.com
# 4. Click "New" → "Web Service"
# 5. Select your GitHub repo
# 6. Settings:
#    - Name: aswang-server
#    - Environment: Node
#    - Build: npm install
#    - Start: npm start
# 7. Click "Deploy"
# 8. Wait 3-5 minutes

# Copy your server URL (e.g., https://aswang-server.onrender.com)
```

### Step 9: Deploy Frontend

```bash
# 1. Go to https://vercel.com
# 2. Click "Add New" → "Project"
# 3. Select your GitHub repo
# 4. Settings:
#    - Root: client
#    - Build: (empty)
# 5. Environment variables:
#    - REACT_APP_SERVER_URL=https://aswang-server.onrender.com
# 6. Click "Deploy"
# 7. Wait 2-3 minutes

# Copy your frontend URL (e.g., https://aswang-night.vercel.app)
```

### Step 10: Install on iOS

```
1. Open Safari on iPhone
2. Go to: https://aswang-night.vercel.app
3. Tap Share button (bottom center, ⬆️)
4. Tap "Add to Home Screen"
5. Name: "Aswang Night"
6. Tap "Add"
7. Done! Tap icon to play
```

---

## 🏗️ NATIVE iOS APP (CAPACITOR) - 20 MINUTES

### Step 11: Install Capacitor

```bash
# Go to project root
cd barangay-aswang-night

# Install Capacitor tools
npm install --save @capacitor/core @capacitor/cli

# Initialize Capacitor project
npx cap init
# When prompted:
# App name: Barangay Aswang Night
# App ID: com.barangay.aswangnight
# Folder: . (current directory)
```

### Step 12: Prepare Web Assets

```bash
# Create www folder with web files
mkdir -p www/js/scenes www/js/entities

# Copy all web files
cp client/index.html www/
cp client/manifest.json www/
cp client/service-worker.js www/
cp -r client/js/* www/js/
cp -r client/assets www/

# Verify www folder has all files
ls -la www/
ls -la www/js/
```

### Step 13: Add iOS Platform

```bash
# This creates the ios/ folder with Xcode project
npx cap add ios

# Expected output:
# ✔ Created ios/App/App.xcworkspace
# ✔ Installed CocoaPods

# Verify ios folder created
ls -la ios/
```

### Step 14: Sync Code

```bash
# Copy web assets to Xcode project
npx cap sync ios

# Expected output:
# ✔ Copied web assets to ios/App/public
# ✔ Updated ios/App/Podfile
```

### Step 15: Open in Xcode

```bash
# Option 1: Use Capacitor command
npx cap open ios

# Option 2: Open manually
open ios/App/App.xcworkspace

# IMPORTANT: Open .xcworkspace NOT .xcodeproj
```

### Step 16: Configure in Xcode

```bash
# In Xcode:
# 1. Click "App" in Project Navigator (left sidebar)
# 2. Select "App" target
# 3. General tab:
#    - Display Name: Aswang Night
#    - Bundle ID: com.barangay.aswangnight
#    - Version: 1.0.0
#    - Build: 1
#    - Min Deployments: iOS 13.0
# 4. Signing & Capabilities:
#    - Team: Select your Apple ID
#    - Hit "Enable Automatically"
# 5. Done!
```

### Step 17: Build & Test

```bash
# Option 1: Test on simulator
# In Xcode: Select simulator (top toolbar)
# Product → Run (Cmd + R)
# Wait 1-2 minutes for build

# Option 2: Test on real iPhone
# Connect iPhone via USB
# Trust computer when prompted
# In Xcode: Select your iPhone
# Product → Run (Cmd + R)
# Wait 2-3 minutes (first time)
```

---

## 📁 COMPLETE FILE LISTING

### Files to Copy FROM

```
manifest.json
service-worker.js
index-pwa.html
js-TouchControls.js
capacitor.config.json
iOS-SETUP.md
iOS-IMPLEMENTATION.md
iOS-UPDATE-SUMMARY.md
```

### Files to Copy TO

```
client/manifest.json                    ← Copy
client/service-worker.js                ← Copy
client/index.html                       ← Copy index-pwa.html and rename
client/js/TouchControls.js              ← Copy
capacitor.config.json                   ← Copy to root
```

### Directories to Create

```
client/js/scenes/                       ← Ensure exists
client/js/entities/                     ← Ensure exists
www/                                    ← Create for Capacitor
www/js/                                 ← Create
www/js/scenes/                          ← Create
www/js/entities/                        ← Create
```

---

## ✅ VERIFICATION COMMANDS

### Check PWA Files

```bash
# Navigate to client folder
cd client

# List all PWA files
echo "=== PWA Files ==="
ls -la manifest.json
ls -la service-worker.js
ls -la index.html
ls -la js/TouchControls.js

# Verify manifest.json is valid JSON
cat manifest.json | python3 -m json.tool > /dev/null && echo "✓ manifest.json is valid"

# Check service-worker.js content
head -20 service-worker.js
```

### Check Capacitor Files

```bash
# Navigate to root
cd ..

# Check Capacitor config
echo "=== Capacitor Files ==="
ls -la capacitor.config.json
cat capacitor.config.json | python3 -m json.tool > /dev/null && echo "✓ capacitor.config.json is valid"

# Check ios folder (after npx cap add ios)
ls -la ios/App/App.xcworkspace/ | head -10
```

### Check GameScene.js Update

```bash
# Verify TouchControls is initialized
grep -n "new TouchControls" client/js/GameScene.js

# Verify direction handling is in update
grep -n "getDirection" client/js/GameScene.js

# Should return line numbers (no errors)
```

---

## 🚀 ONE-LINE SETUP

### PWA Setup (All at Once)

```bash
# Run from project root
mkdir -p client/js && \
cp manifest.json client/ && \
cp service-worker.js client/ && \
cp index-pwa.html client/index.html && \
cp js-TouchControls.js client/js/TouchControls.js && \
echo "✓ PWA files copied!" && \
echo "✓ Update GameScene.js with touch controls" && \
echo "✓ Deploy to Vercel: vercel deploy --prod --cwd client" && \
echo "✓ Done in 5 minutes!"
```

### Capacitor Setup (All at Once)

```bash
# Run from project root
npm install --save @capacitor/core @capacitor/cli && \
mkdir -p www/js/scenes www/js/entities && \
cp client/index.html www/ && \
cp client/manifest.json www/ && \
cp client/service-worker.js www/ && \
cp -r client/js/* www/js/ && \
cp capacitor.config.json . && \
npx cap init && \
npx cap add ios && \
npx cap sync ios && \
echo "✓ Capacitor setup complete!" && \
echo "✓ Run: npx cap open ios" && \
echo "✓ Configure in Xcode and test"
```

---

## 📊 QUICK REFERENCE TABLE

| File | From | To | Action |
|------|------|-----|--------|
| manifest.json | root | client/ | Copy |
| service-worker.js | root | client/ | Copy |
| index-pwa.html | root | client/ | Rename to index.html |
| js-TouchControls.js | root | client/js/ | Copy |
| capacitor.config.json | root | root | Copy (already there) |
| GameScene.js | client/js/ | client/js/ | UPDATE (add touch) |

---

## 🔄 FILE DEPENDENCIES

```
index.html
├── manifest.json (referenced in <link>)
├── service-worker.js (registered in <script>)
├── TouchControls.js (loaded before main.js)
└── main.js (initializes game)

Capacitor
├── capacitor.config.json
├── www/ (copy of client/)
└── ios/ (created by npx cap add ios)
    └── App.xcworkspace (edit in Xcode)
```

---

## 📋 STEP-BY-STEP CHECKLIST

```
PWA Setup:
□ Create client/js directory
□ Copy manifest.json to client/
□ Copy service-worker.js to client/
□ Copy index-pwa.html as client/index.html
□ Copy js-TouchControls.js to client/js/
□ Update GameScene.js with touch handling
□ Test locally: npm start + http-server
□ Deploy backend: Render.com
□ Deploy frontend: Vercel
□ Install on iOS: Safari → Add to Home Screen

Capacitor Setup:
□ npm install @capacitor/core @capacitor/cli
□ npx cap init
□ Create www/ directory
□ Copy all client files to www/
□ npx cap add ios
□ npx cap sync ios
□ Open ios/App/App.xcworkspace in Xcode
□ Configure Team and Bundle ID
□ Test on Simulator: Cmd + R
□ Test on real iPhone: Connect and Cmd + R
```

---

## 🐛 IF SOMETHING GOES WRONG

### Files Not Copying

```bash
# Verify files exist before copying
ls -la manifest.json
ls -la service-worker.js
ls -la index-pwa.html
ls -la js-TouchControls.js

# If missing, re-download them

# Try copying with full path
cp ~/Downloads/manifest.json client/
```

### index.html Still Shows Old Version

```bash
# Clear cache
rm -rf client/.git/cache
rm -f client/index.html.swp

# Verify renaming worked
ls -la client/index.html
cat client/index.html | head -5
# Should show PWA meta tags

# If still wrong, manually rename:
cd client
mv index-pwa.html index.html
cd ..
```

### Capacitor Can't Find www Files

```bash
# Recreate www folder with exact structure
rm -rf www
mkdir -p www/js/scenes www/js/entities

# Copy all files
cp client/index.html www/
cp client/manifest.json www/
cp client/service-worker.js www/
cp -r client/js/* www/js/
ls -la www/
# Should show all files
```

### Xcode Won't Open Project

```bash
# Make sure you're opening xcworkspace, not xcodeproj
open ios/App/App.xcworkspace

# If that fails:
npx cap open ios

# If pods are missing:
cd ios/App
pod install
cd ../..
npx cap open ios
```

---

## 🎯 FINAL COMMANDS

### To Play PWA Today

```bash
# 1. Copy files
mkdir -p client/js
cp manifest.json client/
cp service-worker.js client/
cp index-pwa.html client/index.html
cp js-TouchControls.js client/js/TouchControls.js

# 2. Update GameScene.js (manually add touch controls)

# 3. Deploy to Vercel
cd client
npx vercel deploy --prod

# 4. Open on iPhone
# Safari → Your Vercel URL → Share → Add to Home Screen
```

### To Build Native App Today

```bash
# 1. Install Capacitor
npm install --save @capacitor/core @capacitor/cli

# 2. Setup
npx cap init
npx cap add ios

# 3. Prepare assets
mkdir -p www/js/scenes www/js/entities
cp client/index.html www/
cp -r client/js/* www/js/

# 4. Sync to Xcode
npx cap sync ios
npx cap open ios

# 5. Configure and test in Xcode
# Select Team → Select iPhone → Cmd + R
```

---

## ✨ SUMMARY

### 5 Minutes to iOS (PWA)
```
Copy 4 files → Deploy to Vercel → Add to Home Screen → Done!
```

### 20 Minutes to Native iOS App
```
npm install Capacitor → npx cap init/add ios → Xcode → Configure → Test
```

### Both in 30 Minutes (Recommended)
```
Do PWA first (users play immediately)
Then do Capacitor (professional release)
Launch both, let users choose!
```

---

## 🎉 YOU'RE READY!

**All commands are here. Just copy and paste. Your game will be on iOS today.**

Pick one:
1. **PWA (Fast)** - Copy commands from "PWA Setup"
2. **Capacitor (Professional)** - Copy commands from "Capacitor Setup"
3. **Both (Smart)** - Do PWA first, Capacitor second

---

**🌙 Good luck! Your game is about to reach iOS!** 👹
